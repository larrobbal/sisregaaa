<?php
    class division
    {
        private $idDivision;
        private $division;

        public function getIdDivision()
        {
            return $this->idDivision;
        }

        public function getDivision()
        {
            return $this->division;
        }
    }
?>
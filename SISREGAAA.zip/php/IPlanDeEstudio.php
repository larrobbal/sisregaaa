<?php
    interface IPlanDeEstudio
    {
        public function buscaNombrePlan($idPlanDeEstudio);
        public function getPlanEstudio();
    }
?>
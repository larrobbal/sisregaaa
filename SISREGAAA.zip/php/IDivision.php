<?php
    interface IDivision
    {
        public function getNombreDivision($idDivision);
    }
?>
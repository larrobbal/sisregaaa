<?php
    interface IEstatus
    {
        public function getNombreEstatus($idEstatus);
        public function getEstatusData();
    }
?>
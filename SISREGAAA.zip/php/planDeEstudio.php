<?php
    class planDeEstudio
    {
        private $idPlanEstud;
        private $planEstud;

        public function getIdPlanEstud()
        {
            return $this->idPlanEstud;
        }

        public function getPlanEstud()
        {
            return $this->planEstud;
        }
    }
?>
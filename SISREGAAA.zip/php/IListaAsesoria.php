<?php
    interface IListaAsesoria
    {
        public function addRegistroLista(ListaAsesoria $registroListaAsesoria);
        public function getListDetail($idAsesoria);
    }
?>
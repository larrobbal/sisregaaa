<?php
    interface ISalon
    {
        public function getSalon($idSalon);
    }
?>
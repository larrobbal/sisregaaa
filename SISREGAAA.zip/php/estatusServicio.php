<?php
    class estatusServicio
    {
        private $idEstatusServicio;
        private $estServ;

        public function getIdEstatusServicio()
        {
            return $this->idEstatusServicio;
        }

        public function getEstServ()
        {
            return $this->estServ;
        }
    }
?>
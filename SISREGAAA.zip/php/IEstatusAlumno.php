<?php
    interface IEstatusAlumno
    {
        public function buscaEstatusAlumno($idEstatusAlum);
        public function getEstatusAlumno();
    }
?>
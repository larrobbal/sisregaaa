<?php
    class estatusAlumno
    {
        private $idEstatusAlum;
        private $estAlum;

        public function getIdEstatusAlum()
        {
            return $this->idEstatusAlum;
        }

        public function getEstAlum()
        {
            return $this->estAlum;
        }
    }
?>
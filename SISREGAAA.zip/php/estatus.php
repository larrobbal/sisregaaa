<?php
    class estatus
    {
        private $estatusMateria;
        private $idEstatus;

        public function getEstatusMateria()
        {
            return $this->estatusMateria;
        }
        public function getIdEstatus()
        {
            return $this->idEstatus;
        }
    }
?>
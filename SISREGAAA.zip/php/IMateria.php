<?php
    interface IMateria
    {
        public function consultaIdMateria($nombreMateria);
    }
?>
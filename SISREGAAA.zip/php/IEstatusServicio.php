<?php
    interface IEstatusServicio
    {
        public function getEstatusServicio($idEstatusServ);
        public function getIdEstatus($EstatusServ);
        public function getEstatus();
    }
?>
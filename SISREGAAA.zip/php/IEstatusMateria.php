<?php
    interface IEstatusMateria
    {
        public function getInfoMaterias($idAlumno);
        public function addEstatusMateria(estatusMateria $estatusMateria);
    }
?>